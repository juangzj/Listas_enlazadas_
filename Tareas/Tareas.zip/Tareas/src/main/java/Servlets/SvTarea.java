package Servlets;

import com.umariana.tareas.ControlanrUsuario;
import com.umariana.tareas.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Juan Goyes
 */

@WebServlet(name = "SvTarea", urlPatterns = {"/SvTarea"})
public class SvTarea extends HttpServlet {

    private ArrayList<Usuario> usuarios= new ArrayList<>();
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
        //obtener los parametros para el registro de un nuevo usuario
        String nombre = request.getParameter("nombre");
        String cedula = request.getParameter("cedula");
        String contrasenia = request.getParameter("contrasenia");
        
        System.out.println("Nombre: " + nombre);
        System.out.println("Cedula: " + cedula);
        System.out.println("Contraseña: " + contrasenia);
        
        Usuario nuevosUsuarios =new Usuario(nombre,cedula,contrasenia);
        
        
        
        if (nuevosUsuarios != null) {
            usuarios.add(nuevosUsuarios);
            ControlanrUsuario.guardarUsuario(usuarios);


            String nombreUsuario = nuevosUsuarios.getNomUsuario();
            String script = "<script>alert('Se ha registrado exitosamente.'); window.location.href = 'TareasApp.jsp?nombreUsuario=" + nombreUsuario + "';</script>";
            response.setContentType("text/html");
            response.getWriter().write(script);
        } else {
            // Maneja el caso en el que no se pudo registrar el usuario
            String errorMessage = "No se pudo registrar el usuario";

            // Utiliza JavaScript para mostrar la alerta de error y redirigir después de hacer clic en "Aceptar"
            String script = "<script>alert('" + errorMessage + "'); window.location.href = 'TareasApp.jsp';</script>";
            response.setContentType("text/html");
            response.getWriter().write(script);
        }

        
        
       
        System.out.println("Antes de redireccionar " );
        // Redirecciona a la página de tareas
      

       
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
